import numpy as np
from collections import  deque
import time
import datetime
from collections import  deque
from cmds import commands
from sensor_node import sensor_node
from settings import settings

class scheduler():
    """This class schedules the data collection from the sensor nodes.

    Attributes
    ----------
    stop : if True, the execution stops.
    sensors : sensor_node object to manage the sensor nodes
    comm : bs_comm or sim_comm object to handle the communication with the sensor nodes
    cmds : cmd_queue object to store and prioritize commands
    gui : gui or record object to visualize or store results
    terminal : if True, the execution stops.
    data : a dictionary to store the data collected from all sensor nodes
    data_ptrs : a dictionary to store flags and meta data for all the sensor nodes
    new_data : the env data that is sent to server (in deployments with a server)
    env_len : The number of env samples to keep in the memory. (For cases that post analysis are needed.)
    update_server = if set to True, sends the data collected from the sensor nodes to the server
    battery_check = if set to True, Checks sensor node stored energy and reduce communication rate if needed.
    gui_timeout = GUI refresh timeout
    """

    def __init__(self, comm, cmds, sensors, test_index, gui=None):
        self.stop = False
        self.sensors = sensors
        self.comm = comm
        self.cmds = cmds
        self.gui = gui
        self.terminal = False
        self.data = []
        self.data_ptrs = []
        self.new_data = None
        self.env_len = 30
        self.update_server = settings().update_server
        self.battery_check = settings().battery_check
        self.gui_timeout = settings().gui_timeout

        #initiate time handlers
        self.gui_time = time.time()
        self.env_time = time.time()
        
        #initiate the log file
        self.filename = 'logs/log_pred'+str(test_index)+'.csv'
        self.fh = open(self.filename,"w+")
        print('timestamp,id,success,temp,humid,illum,battery', file= self.fh)

    def add_tag(self, tag_id):
        """adds placeholders for the sensor node data and flags to the data and data_ptrs dictionaries."""
        self.data.append( {'temp':deque(maxlen=self.env_len),
                            'humid':deque(maxlen=self.env_len),
                            'illum':deque(maxlen=self.env_len),
                            'camera':np.zeros((120,120), dtype=np.uint8),
                            'battery' : 170,
                            'success' : 0,
                            'gui_timetag': time.time(),
                            'env_timetag' : deque(maxlen=self.env_len),
                            'suc_timetag': time.time(),})
        self.data[-1]['env_timetag'].append(time.time())

        self.data_ptrs.append({
                             'env_log': 0, 'camera': np.zeros((120,6)), 'image_sen': False, 'env_received': False, 'image_captured': False, 
                             'env_time': time.time(), 'env_trytime': time.time(), 'image_time': time.time()})
        self.data_ptrs[-1]['image_sen'] = self.sensors.get_sensors()[tag_id]['cam']

    def del_tag(self, index):
        """removes the sensor node from the data and data_ptrs"""
        del self.data[index]
        del self.data_ptrs[index]
        del self.data_preds[index]

    def terminate(self):
        self.stop = True


    def run(self):
        """This function iterates over all the sensor nodes, checks if a command should be sent to them,
            executes the commands, and processes the received backscatter packets.

            Returns:
                0 if the execution should continue, otherwise -1.
        """
        if(self.stop or self.terminal):
            return -1

        # generate commands 
        self.update_queue()   

        # send the commands to RX board and process the results
        if (self.cmds.get_size() == 0):
            time.sleep(0.01)
        else:
            while(self.cmds.get_size() > 0):
                cmd = self.cmds.get_cmd()
                self.terminal, pkts = self.comm.cmd(cmd)
                #Analyse tag response to the cmd
                self.process_pkts(cmd, pkts)

        # update GUI and store results on disk
        now = time.time()
        for i,tag in enumerate(self.sensors.get_tags()):
            now = time.time()
                     
            #update GUI column i no data is received over the last "self.gui_timeout" seconds.
            diff = (datetime.datetime.fromtimestamp(now) - datetime.datetime.fromtimestamp(self.data[i]['gui_timetag'])).total_seconds()
            if (diff > self.gui_timeout):
                self.update_gui(i, True)
                self.data[i]['gui_timetag'] = time.time()

            #store results
            if(self.data_ptrs[i]['env_log'] or (len(self.data[i]['temp']) > 0 and diff > self.gui_timeout)):
                self.data_ptrs[i]['env_log'] = False
                print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),',', file= self.fh, end = '', sep='')
                print(tag,',', file= self.fh, end = '', sep='')
                if (settings().SIM):
                    print(1,',', file= self.fh, end = '', sep='')
                else:
                    print(np.round(self.comm.tag_selector[i].get_success_rate(),2),',', file= self.fh, end = '', sep='')
                idx = -1
                print(np.round(self.data[i]['temp'][idx],2),',', file= self.fh, end = '', sep='') 
                print(np.round(self.data[i]['humid'][idx],2),',', file= self.fh, end = '', sep='')
                print(np.round(self.data[i]['illum'][idx],2),',', file= self.fh, end = '', sep='')
                print(np.round(self.data[i]['battery'],2),',', file= self.fh, end = '', sep='')
                print('', file= self.fh)
        return 0        


    def update_queue(self):
        """This function iterates over all the sensor nodes, compares the last received data for each sensor with specified timeouts,
            and add commands to the cmd_queue as needed.
        """

        now = time.time()
        # Try ENV commands till one successful packet is received.
        for i in range(len(self.sensors.get_tags())):
            if (self.data_ptrs[i]['env_received'] == False):
                diff_envtry = (datetime.datetime.fromtimestamp(now) - datetime.datetime.fromtimestamp(self.data_ptrs[i]['env_trytime'])).total_seconds()
                if (diff_envtry > 0.2):
                    self.cmds.add_cmd((i, 0x08))
                    self.data_ptrs[i]['env_trytime'] = now
            else:
                diff_env = (datetime.datetime.fromtimestamp(now) - datetime.datetime.fromtimestamp(self.data_ptrs[i]['env_time'])).total_seconds()
                if (diff_env > self.sensors.get_rates()['env']):
                    self.data_ptrs[i]['env_time'] = now
                    self.data_ptrs[i]['env_received'] = False
                    if (self.update_server):
                        ind = -1
                        self.new_data = [self.sensors.get_tags()[i], self.data[i]['temp'][ind], self.data[i]['humid'][ind], self.data[i]['illum'][ind]]

        # image commands. take new picture if previous picture is received, otherwise request missing pixels
        for i in range(len(self.sensors.get_tags())):
            diff_env = (datetime.datetime.fromtimestamp(now) - datetime.datetime.fromtimestamp(self.data[i]['env_timetag'][-1])).total_seconds()
            if (self.data_ptrs[i]['image_sen']  and diff_env < self.gui_timeout):
                if (self.data_ptrs[i]['image_captured'] == False):
                    diff_img = (datetime.datetime.fromtimestamp(now) - datetime.datetime.fromtimestamp(self.data_ptrs[i]['image_time'])).total_seconds()
                    if (diff_img > self.get_cam_update_rate(i)):
                        self.data_ptrs[i]['image_time'] = now
                        self.cmds.add_cmd((i, 0x03))
                        self.data_ptrs[i]['image_captured'] = True
                else:
                    print('D, image portions received: ', np.sum(self.data_ptrs[i]['camera']))
                    if (np.sum(self.data_ptrs[i]['camera']) >= 720 * self.sensors.get_thr()['cam']):
                        self.data_ptrs[i]['image_captured'] = False
                        self.image_enhan(i)
                        self.data_ptrs[i]['camera'][:] = 0
                        #update GUI
                        self.data[i]['success'] = np.round(self.comm.tag_selector[i].get_success_rate(),2)
                        self.update_gui(i, False)
                        self.data[i]['gui_timetag'] = time.time()
                        # self.data[i]['camera'][:][:] = 0
                    else:
                        self.image_qual_check(i)


    def image_enhan(self, i):
        pass


    def image_qual_check(self, i):
        """ checks the image data for missing pieces. 
        """
        if (np.sum(self.data_ptrs[i]['camera']) < 360):
            self.image_get_whole(i)
        else:
            data_ptrs_row = np.sum(self.data_ptrs[i]['camera'], axis = 1)
            for portion in range(12):
                portion_score = 0
                for row_index in range(10):
                    portion_score +=  data_ptrs_row[portion*10 + row_index]
                # print(portion, self.portion_score)
                if (portion_score < 55):
                    self.cmds.add_cmd((i, (0x10 | portion)))
                else:
                    for row_index in range(10):
                        if (data_ptrs_row[portion*10 + row_index] <6):
                            self.cmds.add_cmd ((i, (0x80 | (portion*10 + row_index))))
                        
    
    
    def image_get_whole(self, i):
        """ generates cmds to read entire image
        """
        
        for x in range (12):
            self.cmds.add_cmd((i, (x | 0x10)))

    def get_cam_update_rate(self, index):
        """ reduce update rate if the stored energy on the sensor node falls below certain thresholds."""
        if (self.battery_check == False):
            return self.sensors.get_rates()['cam']
    
        if (self.data[index]['battery'] > 175):
            return self.sensors.get_rates()['cam']
        elif (self.data[index]['battery'] > 167):
            return 2 * self.sensors.get_rates()['cam']
        elif (self.data[index]['battery'] > 160):
            return 4 * self.sensors.get_rates()['cam']
        else:
            return 100 * self.sensors.get_rates()['cam']
 
    def process_pkts(self, cmd, pkts):
        """ Process the cmds and the received backscatter packets in response to them, extract sensor data, and update data and data_ptrs dictionaries"""

        # Read ENV data
        if (cmd[1] == 0x08):
            for pkt in pkts:
                #make sure the packet is valid
                if(pkt['tag_crc'] == 1 and len(pkt['tag_str']) > 11):
                    # sensor nodes return the receid command in their response. We verify that they received the command correctly.
                    if (pkt['tag_str'][0] == cmd[1]):
                        # check the sensors datasheets for the formulas to convert sensor reading to physical values
                        temp = 165*((pkt['tag_str'][1] + 256*pkt['tag_str'][2])/(65536)) - 40
                        humid = 100*((pkt['tag_str'][3] + 256*pkt['tag_str'][4])/65536)
                        illum_base = 1.2*(pkt['tag_str'][5] + 256*(pkt['tag_str'][6]%16))
                        illum_exponent = 2 ** (pkt['tag_str'][6]//16)
                        illum = illum_base * illum_exponent / 146.21
                        self.data_ptrs[cmd[0]]['env_received'] = True
                        
                        #update data and data_ptrs
                        self.data_ptrs[cmd[0]]['env_log'] = True
                        self.data[cmd[0]]['temp'].append(round(temp, 2))
                        self.data[cmd[0]]['humid'].append(round(humid, 2))
                        self.data[cmd[0]]['illum'].append(round(illum, 2))
                        self.data[cmd[0]]['env_timetag'].append(time.time())

                        #read stored energy value and update previous reading using a weighted moving average formula
                        if (pkt['tag_str'][9] != 0):
                            self.data[cmd[0]]['battery'] = 0.8 * self.data[cmd[0]]['battery'] + 0.2 * pkt['tag_str'][9]
                        
                        #read the 'image_captured' flag
                        if (pkt['tag_str'][7] == 1):
                            self.data_ptrs[cmd[0]]['image_captured'] = True

                        break
                    
                    else:
                        print('D, wrong response', cmd[0], cmd[1], pkt['tag_str'][0])
        
        #Read image portion and row
        if ((cmd[1] & 0xF0 == 0x10) or (cmd[1] & 0x80 == 0x80)):
            for pkt in pkts:
                if(pkt['tag_crc'] == 1 and len(pkt['tag_str']) >= 21):
                    # print(pkt)
                    if (pkt['tag_str'][0] == cmd[1]):
                        # the first two bytes of the packet specify row and column
                        row = pkt['tag_seqNumber'] % 256
                        col = pkt['tag_seqNumber'] // 256

                        if (self.data_ptrs[cmd[0]]['image_sen']):
                            if(row<120 and col<=100):
                                for i in range(20):
                                    self.data[cmd[0]]['camera'][row][col+i] = pkt['tag_str'][i+1]
                                self.data_ptrs[cmd[0]]['camera'][row][col//20] = 1
                           
                    else:
                        pass                  
        
        #Take picture
        if (cmd[1] == 0x03):     
            for pkt in pkts:
                if (pkt['tag_crc'] == 1 and len(pkt['tag_str']) > 2):
                    if (pkt['tag_str'][0] == cmd[1]):
                        # if the sensor node responds correctly to the command, we assume that it has captured the image.
                        self.data_ptrs[cmd[0]]['image_captured'] = True
                    else:
                        pass    
            # wait until the sensor node completes the image capture
            time.sleep(2)                

    def update_gui(self, index, timeout):
        """update GUI column for the sensor tag specified by index"""
        if(self.gui != None and self.stop == False):
            self.gui.submit_to_tkinter(self.gui.update, self.data, self.data_ptrs, index, timeout)
