from sim_comm import sim_comm
from bs_comm import bs_comm
from scheduler import scheduler
from sensor_node import sensor_node
import socketio
import json
from settings import settings

"""
We use the socket.io package to communicate between RX units and the server.
The following events are used as needed.

parameters:
server_ip: IP address of the server
rx_id: The RX unit unique ID
sio: socket.io client object
incoming_sensors: list of sensor node IDs received from the server to search for. 
reg_sensors: list of sensor nodes found by this RX unit and are assigned to it to communicate with them.
"""

server_ip = settings().server_ip
rx_id = settings().rx_id
sio = socketio.Client()
incoming_sensors = []
reg_sensors = {}

@sio.on("connect")
def connect():
    print('connection established')
    # send the connected device ID to the server upon connection
    sio.emit('reg_rx', {'id': rx_id})

@sio.on("disconnect")
def disconnect():
    print('disconnected from server')
    
@sio.event
def sensors_missed(data):
    global incoming_sensors
    print('sensors_missed', data)
    #add the missing sensors IDs received from the server to the incoming_sensors list
    for item in data:
        if (int(item) not in incoming_sensors):
            incoming_sensors.append(int(item))
    print ('incoming sensors: ', incoming_sensors)

@sio.event
def sensors_reg(data):
    global reg_sensors
    print('sensors_reg', data)
    # add (or update) the registered sensors IDs and list of available sensors to the reg_sensors dictionary.
    for item in data:
        reg_sensors[int(item)] = data[item]
    print('reg_sensors: ', reg_sensors)



class sensor_manager:
    """ This class is used to initialize the system, handle the communication with the server, add or delete sensor nodes, 
        search for missing sensor nodes received from the server, and execute all the tasks to collect data in a for-ever loop.

        Attributes
        ----------
        sio: socket.io client object
        incoming_sensors: list of sensor node IDs received from the server to search for. 
        sch: the scheduler object to manage data collection
        comm: the bs_comm or sim_comm object to manage the communication
        sensors: the sensor_node object to manage sensors
        terminal: if True, the execution stops.
        DROP_THR: if a sensor node does not respond to the RX units over DROP_THR communication attempts it would be classified as missing.
        START_THR: Initially, it might take longer to form connection to a sensor node. 
                   During the first START_THR communication cycles the sensor node is not classified as missing.
    """
    def __init__(self, scheduler, comm, sensors):
        global sio
        global incoming_sensors
        self.sch = scheduler
        self.comm = comm
        self.sensors = sensors
        self.terminal = False
        self.DROP_THR = 20
        self.START_THR = 70

        # connect to the server
        sio.connect(server_ip)

    def run(self):
        while(True):
            if(self.terminal):
                break
            
            # search for any sensor in the incoming_sensors list
            if (len(incoming_sensors) > 0):
                self.search_tags()
            
            # add any sensor in the reg_sensors dictionary
            if (len(reg_sensors) > 0):
                self.add_tags()

            # check if the current active sensors are missing, and collect their data 
            if (len(self.sensors.get_tags()) > 0):
                self.check_missing()
                res = self.sch.run()
                if (self.sch.new_data != None):
                    sio.emit('new_data', self.sch.new_data)
                    self.sch.new_data = None
                if (res != 0):
                    break
        sio.disconnect()

    
    def check_missing(self):
        """ checks if any of the active sensor nodes is missing"""
        missed_tags = []
        for (index,tag) in enumerate(self.sensors.get_tags()):
            # The missing criteria is defined as no response over the past DROP_THR cycles,
            # when at least START_THR has passed.
            rate = self.comm.get_hist_rate(index, self.DROP_THR, self.START_THR)
            if (rate != None and rate == 0):
                missed_tags.append(tag)
                self.del_tag(index, tag)
                print('tag %d deleted.'%(tag))

        #send list of missing sensor nodes to the server
        if (len(missed_tags) > 0):
            sio.emit('miss_tags', missed_tags)
        

    def add_tags(self):
        """ adds sensor nodes from the ref_sensors dictionary to the active sensors"""
        global reg_sensors
        for tag in reg_sensors:
            if tag in self.sensors.get_tags():
                pass
            else:
                self.add_tag(tag, reg_sensors[tag])
        reg_sensors = {}

    def add_tag(self, tag, sensors):
        """ adds an individual sensor node to the system"""
        self.sensors.add_tag(tag, sensors)
        self.sch.add_tag(tag)
        self.comm.add_tag(tag)

    def del_tag(self, index, tag):
        """ deletes a sensor node"""
        self.sensors.del_tag(index, tag)
        self.sch.del_tag(index)
        self.comm.del_tag(index)

    def search_tags(self):
        """ search for all the sensors in the incoming list and send the search result back to the server"""
        global incoming_sensors
        search_res = {}
        for tag in incoming_sensors:
            search_res[tag] = self.search_tag(tag)
        sio.emit('search_res', search_res)
        incoming_sensors = []

    def search_tag(self, tag_id):
        """ searches for a sensor node with ID equal to tag_id.
            the search procedure uses max power and set of equally spaced frequency channels using every available TX units
        """
        TXs = self.sensors.get_TXs(tag_id)
        powers = [6]
        freqs = [0, 6, 12, 18, 24, 30, 36, 42, 48, 53, 58, 64]
        res = {}
        for TX in TXs:
            suc = 0
            for freq in freqs:
                for power in powers:
                    self.terminal, success = self.comm.direct_cmd(TX, tag_id, 0x08, 15, 3, [freq, 0, 0, 0, power])
                    if (success > 0.5):
                        suc += 1
            res[TX] = suc
        print('tag_id: ', tag_id, 'res:', res)
        return res