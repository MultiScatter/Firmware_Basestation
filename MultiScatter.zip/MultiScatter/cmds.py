from settings import settings
import queue
from enum import Enum
from sensor_node import sensor_node


class commands():
    """A class for defining all the valid commands."""

    def __init__(self):
        self.READ_ENV = 0x08
        self.TAKE_PIC = 0x03
        self.READ_PIC_POR = 0x10 #0x10-0x1B
        self.READ_PIC_ROW = 0x80 #0x80-0xF7


class cmd_queue:
    """A class for managing the commands issued to the sensor nodes.
    The commands are simply stored in a queue, and execute one by one.

    Attributes
    ----------
    queue: The queue to store the commands.
    print_cmds: if True, prints the commands sent to the sensor nodes on the console.
    tags: list of the currently active sensor nodes in the system.
    """

    def __init__(self, sensors):
        self.queue = queue.Queue()
        self.print_cmds = settings().print_cmds
        self.tags = sensors.get_tags()

        #specify the duration of the responses to the different commands.
        #the response duration depends on the number of expected packets, and the data rate. (length of packets are fixed).
        #the numbers are in 2ms. For example DUR_N_PKTS = 100 means that the RX unit wait for 200ms to receive the backscatter response.
        if (settings().DATA_RATE == 62):
            self.DUR_1_PKTS = 10
            self.DUR_3_PKTS = 15
            self.DUR_6_PKTS = 22
            self.DUR_40_PKTS = 150
            self.DUR_60_PKTS = 200
        elif (settings().DATA_RATE == 125):
            self.DUR_1_PKTS = 7
            self.DUR_3_PKTS = 11
            self.DUR_6_PKTS = 18
            self.DUR_40_PKTS = 80
            self.DUR_60_PKTS = 95
        elif (settings().DATA_RATE == 250):
            self.DUR_1_PKTS = 5
            self.DUR_3_PKTS = 8
            self.DUR_6_PKTS = 15
            self.DUR_40_PKTS = 55
            self.DUR_60_PKTS = 70
        else:
            self.DUR_1_PKTS = 18
            self.DUR_3_PKTS = 25
            self.DUR_6_PKTS = 35
            self.DUR_40_PKTS = 200
            self.DUR_60_PKTS = 250

    def get_size(self):
        return self.queue.qsize()
    
    def get_cmd(self):
        return self.queue.get()

    def add_cmd(self, cmd):
        """adds a command to the queue.
        The added command specifies the sensor node id, command, response duration, and expected number of packets
        """

        # Read env sensors
        if (cmd[1] == commands().READ_ENV):
            self.queue.put([cmd[0], commands().READ_ENV, self.DUR_3_PKTS, 3])
            if (self.print_cmds):
                print('C,',self.tags[cmd[0]],',ENV')
        
        # Take picture
        elif (cmd[1] == commands().TAKE_PIC):
            self.queue.put([cmd[0], commands().TAKE_PIC, self.DUR_3_PKTS, 3])
            if (self.print_cmds):
                print('C,',self.tags[cmd[0]],',TAKE_PIC')
                
        # Read pic portion
        elif ((cmd[1] & 0xF0) == commands().READ_PIC_POR):
            self.queue.put([cmd[0], cmd[1], self.DUR_60_PKTS, 60])
            if (self.print_cmds):
                print('C,',self.tags[cmd[0]],',READ_PIC_P,', cmd[1] - 0x10)

        # Read pic row
        elif (cmd[1] & 0x80 == commands().READ_PIC_ROW):
            self.queue.put([cmd[0], cmd[1], self.DUR_6_PKTS, 6])
            if (self.print_cmds):
                print('C,',self.tags[cmd[0]],',READ_PIC_R,', cmd[1] - 0x80)

