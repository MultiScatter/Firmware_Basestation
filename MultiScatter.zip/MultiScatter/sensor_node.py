from settings import settings


class sensor_node:
    """A class used to manage the sensor nodes.

    Attributes
    ----------
    tags : list of the currently active sensor nodes in the system. The RX unit tries to communicate with all the sensor nodes in this list.
    TXs : a dictionary where keys are the sensor node ids, and values are list of TX units associated with that sensor node
    sensors : A dictioary that specifies which sensors are available on each sensor node.
    rates : target update rate for each sensor type
    thr : specifies the portion of the data that should be successfully received to accept the new frame. (used for cameras)
    """

    def __init__(self):
        self.tags = []
        self.TXs = {}
        self.sensors = {}
        self.rates = settings().update_rates
        self.thr = settings().sensor_th
    
    def get_tags(self):
        return self.tags

    def get_sensors (self):
        return self.sensors


    def get_rates (self):
        return self.rates

    
    def get_thr (self):
        return self.thr


    def get_TXs (self, tag_id):
        """returns the list of TX units associatedwith a sensor node
        If the sensor node is not in 'tags' list, the function retirns a list of all Tx units that listen to the RX unit.

        Parameters
        ----------
        tag_id : sensor node id.
        """

        if (tag_id in self.TXs):
            return  self.TXs[tag_id]
        else:
            return settings().active_TXs


    def add_tag(self, tag_id, active_sensors, TXs = settings().active_TXs):
        """adds a new sensor node to the 'tags' list.

        Parameters
        ----------
        tag_id : sensor node id.
        active_sensors : a dictionary that specifies which sensors are available on the sensor node.
        TXs: optional, a list of the TX units associated with that sensor node
        """

        self.tags.append(tag_id)
        self.TXs[tag_id] = TXs
        self.sensors[tag_id] = active_sensors


    def del_tag(self, index, tag_id):
        """removes a sensor node from the 'tags' list.
        
        Parameters
        ----------
        index: the sensor node index in the 'tags' list.
        tag_id : sensor node id.
        """

        del self.tags[index]
        del self.TXs[tag_id]
        del self.sensors[tag_id]


