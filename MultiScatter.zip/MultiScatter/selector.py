import numpy as np
import random 
from collections import  deque

class selector_history():
    """A class for tracking the effectiveness of an smart policy in suggesting configurations for backscatter communication.
    And used for selecting between the smart policy and exploratory policy (random selection).
    This class keeps a history of the success rate over the past "hist_len" attempts, and use it to evaluate the smart policy in use.

    Attributes
    ----------
    hist_len: length of prior communication results used.
    explore: if False, always the smart policy is selected.
    hist: a circular array of size "hist_len" to store the prior communication results.
    """

    def __init__(self, hist_len, explore=True):
        self.hist_len = hist_len
        self.explore = explore   
        self.hist = deque(maxlen=hist_len)

    def reset(self):
        #clear all the stored communication results.
        self.hist = deque(maxlen=self.hist_len)

    def get_success_rate(self):
        # returns average success rate 
        return np.mean(self.hist)

    def update(self, config, res):
        # add an entry to the circular buffer
        self.hist.append(res)

    def select(self):
        if self.explore:
            # we use a deterministic function to select between the smart polict and exploratory polict based on the average success rate
            explore_rate = 1 - np.tanh(3*self.get_success_rate()) / np.tanh(3)
            return explore_rate
        else:
            return 0

    def get_hist(self, n, start):
        # get a portion of the stored history
        if (start > len(self.hist)):
            return None
        else:
            return sum(self.hist[-n : ])