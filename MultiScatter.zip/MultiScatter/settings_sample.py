class settings:
    """A class used to specify the execution settings.

    Attributes
    ----------
    port : Serial port name
    GUI: If set to "True", the data collected from the sensor nodes is shown on a GUI.
          If set to "False", the data is just stored on disk.
    SIM: This is for testing. If set to "True", random packets are generated from the communication module
        instead of collecting data from the sensor nodes. If set to "False", data is collected through backscatter packets.
    LOCAL: If set to "True", the application receives the list of the sensor nodes from the server, search for them,
           and updates the server with the search result. If set to "False" the application uses the active_tags list in settings file.
    server_ip : The ip address of the server. (in case LOCAL is set to False)
    update_server : if set to True, sends the data collected from the sensor nodes to the server
    DEBUG : if set to True, prints raw communications with the sensor nodes on the console
    rx_id : receiver unit id, in systems with more than one receiver and a server.
    DATA_RATE : Backscatter communication data rate in Kbps, possible values are: 31, 62, 125, 250.
    battery_check : if set to True, Checks sensor node stored energy and reduce communication rate if needed.
    gui_timeout : GUI refresh timeout
    print_cmds : prints commands sent to the sensor nodes on the console
    active_tags : if LOCAL is True, list of sensors that the RX unit should attempt to communicate with.
                  if LOCAL is false, the server sends the list of the tags to the RX unit.
    active_sensors: A dictioary that specifies which sensors are available on each sensor node.
    active_TXs : if LOCAL is True, a dictionary where keys are the sensor node ids, and values are list of associated TXs for that sensor node
                  if LOCAL is set to False, a list of all TX units that listen to this RX unit.
    update_rates : target update rate for each sensor type
    sensor_th : specifies the portion of the data that should be successfully received to accept the new frame. (used for cameras)
    """

    def __init__(self):
        self.port = 'COM32'
        self.server_ip = 'http://10.19.112.43:5000'
        self.GUI = True
        self.SIM = True
        self.LOCAL = False
        self.DEBUG = True
        self.update_server = True
        self.rx_id = 0
        self.DATA_RATE = 125
        self.battery_check = False
        self.gui_timeout = 5
        self.print_cmds = True

        self.active_tags = [0]

        self.active_sensors = { 0:{'cam' : True},
                                3:{'cam' : False},
                                4:{'cam' : False},
                                6:{'cam' : False}
                }

        active_TXs = [0]
        if (self.LOCAL == True):
            self.active_TXs =  {0:active_TXs,
                                3:active_TXs,
                                4:active_TXs,
                                6:active_TXs}
        else:
            self.active_TXs = active_TXs

        self.update_rates = {   'cam' : 30,
                                'env' : 0.1}

        self.sensor_th = {  'cam' : 0.99}

