from sim_comm import sim_comm
from bs_comm import bs_comm
from scheduler import scheduler
from sensor_node import sensor_node
import numpy as np
from settings import settings

active_tags = settings().active_tags
active_sensors =  settings().active_sensors
active_TXs =  settings().active_TXs

class sensor_manager_local:
    """ This class is used to initialize the system by adding all the sensor nodes to different objects
        and execute all the tasks in a for-ever loop.
    """
    def __init__(self, scheduler, comm, sensors):
        self.sch = scheduler
        self.comm = comm
        self.sensors = sensors
        self.terminal = False
        for tag in active_tags:
            self.add_tag(tag, active_sensors[tag])


    def run(self):
        """ forever loop to run the program
        """
        while(True):
            if(self.terminal):
                break

            res = self.sch.run()
            if (res != 0):
                break

    def add_tag(self, tag, sensors):
        """ add a sensor node to the system"""
        self.sensors.add_tag(tag, sensors, TXs = active_TXs[tag])
        self.sch.add_tag(tag)
        self.comm.add_tag(tag)


    def search(self):
        """ search for all the sensor nodes in the active_tags list. mainly used in evaluations."""
        for tag in active_tags:
            self.search_tag(tag)
    
    def search_tag(self, tag_id):
        """ This function searches for a specific sensor node (tag_id) by trying to communicate with it using different TXs and
            over several CW signal freqiency and power settings. The results are saved in a test file.
        """
        TXs = self.sensors.get_TXs(tag_id)
        powers = [i for i in range(8)]
        freqs = [i for i in range(65)]
        res = np.zeros((len(freqs), len(powers)))
        
        fh= open('test_index.txt',"r")
        test_index = int(fh.readline())
        fh.close()
        
        for TX in TXs:
            max_suc = 0
            avg_suc = 0
            for freq in freqs:
                for power in powers:
                    self.terminal, success = self.comm.direct_cmd(TX, tag_id, 0x08, 15, 3, [freq, 0, 0, 0, power])
                    avg_suc += success
                    if (success > max_suc):
                        max_suc = success
                    res[freq,power] = success
            avg_suc /= (len(freqs) * len(powers))
            print('res:', avg_suc)

            outfile = "search\\res"+str(test_index)+'_'+str(TX)
            np.save(outfile, res)

        fh= open('test_index.txt',"w+")
        print(test_index+1, file= fh)
        fh.close()