import time
import serial
import numpy as np
import random 
from datetime import datetime

class rxInterface:
    """A class for communicating to the embedded RX board.

    Attributes
    ----------
    log : if True, logs every cmd to the RX board, and every backscattrered packet received from the board in a text file
    debug : if True, prints debug parameters including the result of each command on the console
    terminal_count : Used to run the program for a pre-defined number of commands. Mostly used in evaluations. The program stops when hits the terminal_count.
    test_count : number of received commands from the start of the execution.
    terminal : True when test_count reaches the terminal_count.
    port : the serial port used to communicate with the RX board.
    """

    def __init__(self, port='COM5', filename= 'log.txt', log= True, debug= True, terminal_count= None):
        self.log = log
        self.debug = debug
        self.test_count = 0
        self.terminal = False
        self.port = serial.Serial(
            port=port,
            baudrate=500000,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            bytesize=serial.EIGHTBITS,
            timeout=2
        )

        if (self.port.isOpen()):
            print ('Starting Whisper, Rev 1.0 ...\r\n')
        else:
            print ('ERROR. UNABLE TO OPEN SERIAL PORT\r\n')

        if (filename != None and log):
            self.fh= open(filename,"w+")
            print('time;type;tag_index;tx_index;freq;power;tag_cmd;seq_num;str;rssi;intfr;crc', file= self.fh)
        else:
            print("LOG IS TURNED OFF.")
            self.log = False

        if(terminal_count != None):
            self.terminal_count = terminal_count
        else:
            self.terminal_count = np.inf

    def cmd(self, tx_index, tag_index, tag_config, duration, tag_cmd):
        """This function send a command to the RX board, and stores all the backscattered packets received in response.

        tx_index: The TX unit ID that should provide the CW signal for backscatter communication.
        tag_index: sensor board ID that should respons to the command.
        tag_config: the configurations that should be used to achieve best communication performance with the specified sensor node.
                    the configuration includes CW signal frequency, TRX antenna (if the devices have more than one antenna), wake up source 
                    (in systems where both devices can wake the sensor node), and CW signal power.
        duration: specifies the duration that RX board should wait for the backscatter packet responses. (and TX board should transmit the CW signal)
        tag_cmd : the command that should be sent to the sensor node.

        Returns:
            terminal : True if the terminal threshold is met
            attempt : True if the command has been sent to the RX board
            pkt_count_crcOk : number of received packets with correcr CRC.
            pkt_count_crcNok : number of received packets with incorrect CRC
            rssi : average rssi of the correct packets
            pkts : a list that contains all the received packets info
        """
        #send the data to the RX board in a 7-byte array
        freq_index = tag_config[0]
        tx_ant = 0#tag_config[1]
        rx_ant = 1#tag_config[2]
        tx_wakeup = 1#tag_config[3]
        power = tag_config[4]
        tag_ant = 0
        byte_array = [tx_index, tag_index, freq_index, tag_cmd, duration, power, 0]
        byte_array[-1] = ((tx_wakeup << 3) | (tag_ant << 2) | (tx_ant << 1) | (rx_ant))
        self.port.write(bytes(byte_array))
        if(self.log):
            print(datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], 'CMD', tag_index, tx_index, freq_index, power, tag_cmd, sep=';',file= self.fh)


        #get the backscatter communication results
        pkt_count_crcOk = 0
        pkt_count_crcNok = 0
        rssi = 0
        rxBuff = []
        pkts = []

        intfr = -256
        attempt = True
        
        while(True):
            #read one byte from serial port
            readback = self.port.read(size = 1)
            if(len(readback) > 0):
                rxBuff.append(int(readback[0]))
            else:
                #terminate the loop if no byte was available on the serial port (the pyserial has a timeout) 
                break
            # print(rxBuff)

            if(len(rxBuff) >= 9):
                #check for a specific pattern at the end of byte array
                if(rxBuff[-4] == 0x55 and rxBuff[-3] == 0xaa and rxBuff[-2] == 10 and rxBuff[-1] == 13):
                    # store each received packet data in a dictionary
                    pkt = {}
                    pkt['tag_header'] = rxBuff[0]
                    pkt['tag_seqNumber'] = rxBuff[1] + rxBuff[2]*256
                    pkt['tag_rssi'] = rxBuff[-6] - 256
                    pkt['tag_crc'] = rxBuff[-5]
                    if((pkt['tag_seqNumber'] == 43605) and (pkt['tag_rssi'] == -246) and (pkt['tag_crc'] == 13)):
                        #termination packet is received. This is the last packet.
                        intfr = pkt['tag_header']
                        break
                    else:
                        #store the payload and interference level
                        pkt['tag_str'] = rxBuff[3:-8]
                        pkt['intfr'] = rxBuff[-7] - 256
                        #add the pkt to the pkts list.
                        pkts.append(pkt)

                        if(self.log):
                            print(datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], 'RES', tag_index, tx_index, freq_index, power, tag_cmd, pkt['tag_seqNumber'], pkt['tag_str'], pkt['tag_rssi'], pkt['intfr'], pkt['tag_crc'], sep=';',file= self.fh)
                            
                        #clear the serial buffer
                        rxBuff = []

                        #update the rssi calculation
                        if(pkt['tag_crc'] == 1):
                            rssi += pkt['tag_rssi']
                            pkt_count_crcOk += 1
                        else:
                            # rssi += (pkt['tag_rssi'])
                            pkt_count_crcNok += 1

        #in current system, interference is measured once for all backscatter packets. We can just select the intfr for the first packet.             
        if ((pkt_count_crcOk + pkt_count_crcNok) != 0):
            intfr = pkts[0]['intfr']

        #divide rssi by the number of packets to get the average rssi
        if ((pkt_count_crcOk) != 0):
            rssi /= (pkt_count_crcOk)
        else:
            rssi = -256

        if(self.debug):
            print('R, {:>12}, {:>3}, {:>3}, {:>3}, {:>2}, {:>2}, {:>2}, {:>7}, {:>5}, {:>4}'\
            .format(datetime.utcnow().strftime('%m-%d %H:%M:%S'), tag_index, tx_index, tag_config[0], power, pkt_count_crcOk, pkt_count_crcNok, np.round(rssi,2), np.round(intfr,2), tag_cmd), end = '')

        self.test_count += 1
        if(self.test_count > self.terminal_count):
            self.terminal = True
            # self.fh.close()
        
        return self.terminal, attempt, pkt_count_crcOk, pkt_count_crcNok, rssi, pkts
