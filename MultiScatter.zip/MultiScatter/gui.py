import tkinter as tk
import queue
from PIL import Image, ImageTk, ImageEnhance, ImageFilter
import numpy as np
import math
import os
from datetime import datetime
from scipy.io.wavfile import write



cam_DIR = "recorded_images"

class gui:
    """This class creates a simple GUI using tkinter to visualize the collected data.
    """

    def __init__(self):
        self.root = None
        self.labels = []
        self.meas = []
        self.measTexts = []
        self.request_queue = queue.Queue()
        self.result_queue = queue.Queue()
        self.blankarray = np.zeros((120,120))
        self.blankImage = None           

    def submit_to_tkinter(self, callable, *args, **kwargs):
        self.request_queue.put((callable, args, kwargs))
        return self.result_queue.get()

    def init(self, sensors, save):
        self.tags = sensors.get_tags()
        self.cols = len(self.tags)
        self.sensors = sensors.get_sensors()
        self.save = save
        for tag in self.tags:
            if (self.sensors[tag]['cam']):
                try:
                    os.mkdir(cam_DIR+str(tag))
                except:
                    pass  

    def run(self):
        self.root = tk.Tk()
        self.root.title("MultiScatter")
        w = 190 * (1 + self.cols) # width for the Tk root
        h = 950 # height for the Tk root
        # get screen width and height
        ws = self.root.winfo_screenwidth() # width of the screen
        hs = self.root.winfo_screenheight() # height of the screen
        # calculate x and y coordinates for the Tk root window
        x = (ws/2) - (w/2)
        y = 0
        # set the dimensions of the screen and where it is placed
        self.root.geometry('%dx%d+%d+%d' % (w, h, x, y))

        frame = tk.LabelFrame(self.root, padx=5, pady=5)
        button_exit = tk.Button(self.root, text="Exit Program", command=self.root.quit)

        frame.grid(row=0, column=0, padx=10, pady=10)
        button_exit.grid(row=1, column=0)

        cw = 10
        ch = 3
        temp = tk.Label(frame, text='Temperature', height= ch, width = cw)
        temp.grid(row=1, column=0)
        humid = tk.Label(frame, text='Humidity', height= ch, width = cw)
        humid.grid(row=2, column=0)
        illum = tk.Label(frame, text='Illuminance', height= ch, width = cw)
        illum.grid(row=3, column=0)
        battery = tk.Label(frame, text='Battery', height= ch, width = cw)
        battery.grid(row=4, column=0)
        success = tk.Label(frame, text='Success rate', height= ch, width = cw)
        success.grid(row=5, column=0)
        last = tk.Label(frame, text='Last update', height= ch, width = cw)
        last.grid(row=6, column=0)
        image = tk.Label(frame, text='Image', height= ch, width = cw)
        image.grid(row=7, column=0)
        self.resText = tk.StringVar()
        self.res = tk.Label(frame, textvariable=self.resText, height= ch, width = cw)
        self.res.config(font=("Courier", 30))
        self.res.grid(row=10, column=(self.cols+1)//2)

        self.blankImage = ImageTk.PhotoImage(image=Image.fromarray(self.blankarray))
        
        for i in range(self.cols):
            self.labels.append(None)
            self.labels[-1] = tk.Label(frame, text='Tag '+str(self.tags[i]), height= ch, width = cw)
            self.labels[-1].grid(row=0, column=i+1)

            self.meas.append([None, None, None, None, None, None, None, None])
            self.measTexts.append([None, None, None, None, None, None])
            for j in range(6):
                self.measTexts[-1][j] = tk.StringVar()
                self.meas[-1][j] = tk.Label(frame, textvariable=self.measTexts[-1][j])
                self.meas[-1][j].grid(row=j+1, column=i+1)
            
            if (self.sensors[self.tags[i]]['cam']):
                self.meas[-1][7] = tk.Label(frame,width=120,height=120, image=self.blankImage)
                self.meas[-1][7].grid(row=8, column=i+1)

        self.timertick()
        self.root.mainloop()
        
    def timertick(self):
        try:
            callable, args, kwargs = self.request_queue.get_nowait()
        except queue.Empty:
            pass
        else:
            # print ("GUI data updated.")
            retval = callable(*args, **kwargs)
            self.result_queue.put(retval)

        self.root.after(200, self.timertick)

    def update(self, data, data_ptrs, index, timeout):
        """This function updates one column of the GUI associated to the "index" sensor node.

        Args:
        data: The data dictionary passed from the scheduler.
        data_ptrs: the data_ptrs dictionary passed from the scheduler.
        index: the sensor node index that needs to get updated.
        timeout: Whether this update is caused by a GUI timeout, or receiving a new image.
        """
        i = index
        tag = self.tags[i]

        # idx = data_ptrs[i]['env']
        if (data[i]['temp']):
            idx = -1
            temp = data[i]['temp']
            self.measTexts[i][0].set(str(temp[idx]))
            humid = data[i]['humid']
            self.measTexts[i][1].set(str(humid[idx]))
            illum = data[i]['illum']
            self.measTexts[i][2].set(str(illum[idx]))
            battery = data[i]['battery']
            self.measTexts[i][3].set(str(np.round(battery,2)))
            success = data[i]['success']
            self.measTexts[i][4].set(str(success))
            last = datetime.now().strftime("%H:%M:%S")
            self.measTexts[i][5].set(last)

            if (not timeout):
                if (self.sensors[tag]['cam']):
                    array = data[i]['camera']
                    im = Image.fromarray(array)
                    #save image
                    if (self.save):
                        im.save(cam_DIR+str(tag) + '/'+ datetime.now().strftime("%Y-%m-%d_%H%M%S")+".bmp")

                    im = im.filter(ImageFilter.SMOOTH) # Smooth out noise
                    im = im.filter(ImageFilter.DETAIL) # Enhance details

                    #create image
                    array = np.asarray(im)
                    img =  ImageTk.PhotoImage(image=Image.fromarray(array))
                    #show image
                    self.meas[i][7].configure(image = img)
                    self.meas[i][7].image = img