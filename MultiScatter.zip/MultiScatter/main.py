#LD_PRELOAD=/usr/lib/arm-linux-gnueabihf/libatomic.so.1 python3 main.py

from threading import Thread
from sim_comm import sim_comm
from bs_comm import bs_comm
from gui import gui
from record import record
from scheduler import scheduler
from cmds import cmd_queue
from sensor_node import sensor_node
from sensor_manager import sensor_manager
from sensor_manager_local import sensor_manager_local
import time
import os
import platform
from settings import settings
from glob import glob

def main(port, GUI=False, SIM=False, LOCAL = False):
    """The main function to run the program.

    This function collects sensor data (temp, humidity, illuminance, image) from the backscatter sensor nodes
    and display the collected data on the screen or store it on the disk. If needed, it updates a server with
    the list of connected nodes.
    Example: main(port='COM5', GUI=True, SIM=False, LOCAL = True)

    Args:
        port: the serial port name to communicate with the RX board.
        GUI: If set to "True", the data collected from the sensor nodes is shown on a GUI.
             If set to "False", the data is just stored on disk.
        SIM: This is for testing. If set to "True", random packets are generated from the communication module
            instead of collecting data from the sensor nodes. If set to "False", data is collected through backscatter packets.
        LOCAL: If set to "True", the application receives the list of the sensor nodes from the server, search for them,
               and updates the server with the search result. If set to "False" the application uses the active_tags list in settings file.
        
    Returns:
        None
    """

    # Auto create logs if not already exist
    if not os.path.exists('logs'):
        os.makedirs('logs')

    # Unique auto-increment log 
    prev_log = glob('logs/*.csv')
    if len(prev_log) == 0:
        test_index = 1 
    else:   
        test_index = max([int(os.path.basename(i).split('.')[0][8:]) for i in prev_log])+1
    fname = 'logs/log'+str(test_index)+'.txt'

    sensors = sensor_node()
    cmds = cmd_queue(sensors)
    if (GUI):
        visual = gui()
    else:
        visual = record(sensors, save=True)
    if (SIM):
        comm = sim_comm(pktLen=24, pkt_prob=0.95)
    else:
        comm = bs_comm()
        comm.init(port=port, sensors = sensors, filename= fname, ant_div=True, term_count=None, debug=settings().DEBUG, explore=True)
    sch = scheduler(comm, cmds, sensors=sensors, test_index=test_index, gui=visual)
    if (LOCAL == True):
        manager = sensor_manager_local(sch, comm, sensors)
    else:
        manager = sensor_manager(sch, comm, sensors)

    if (GUI):
        thread = Thread(target=manager.run)
        thread.start()
        while(not sensors.get_tags()):
            pass
        visual.init(sensors, save=True)
        visual.run()
        sch.terminate()
        thread.join()
    else:
        manager.run()



if __name__ == '__main__':   
    main(port=settings().port, GUI=settings().GUI, SIM=settings().SIM, LOCAL = settings().LOCAL)

