import eventlet
import socketio
import time
import datetime
import random
import os
from glob import glob

"""
We use the socket.io package to communicate between RX units and the server.
The following events are used as needed.

parameters:
all_sensors: A dictionary where the key is a sensor node ID, and the value determines which sensors is available on that sensor node
active_sensors: A subset of all_sensors that we are trying to communicate with.
reg_sensors: A subset of active sensors that are assigned to RX units.
miss_sensors: The keys are a subset of active sensors that are not assigned to any RX unit, and should be search for in the coverage area.
              The values are a dictionary of RX units that used to search for sensor node with a timetag.
pending_sensor: list of sensors that are assigned to a RX unit for searching, but the search result is not received yet.
RXs: A disctionary where keys are the RX ID of the connected RX units, and values are their SID
SIDs: A disctionary where keys are the SID of the connected RX units, and values are the RX ID
fname = name of the log file
sio: socket.io server object
"""

all_sensors =  { 0:{'cam' : False},
                    2:{'cam' : False},
                    3:{'cam' : True},
                    4:{'cam' : False},
                    8:{'cam' : False},
                    9:{'cam' : False}
                }
active_sensors = [0]
reg_sensors = {}
miss_sensors = {}
pending_sensor = []
RXs = {}
SIDs = {}
fname = None
sio = socketio.Server()
app = socketio.WSGIApp(sio)



@sio.on("connect")
def connect(sid, environ):
    print('connect ', sid)



@sio.on("disconnect")
def disconnect(sid):
    """ handles the disconnect event
    """

    global miss_sensors
    print('disconnect ', sid)
    for sensor in list(reg_sensors):
        # removes the sensor nodes assigned to the RX unit from pending and reg_sensor and add them to the miss_sensors
        if (int(sensor) in pending_sensor):
            pending_sensor.remove(int(sensor))
        if(reg_sensors[sensor] == SIDs[sid]):   
            del reg_sensors[sensor]
            miss_sensors[sensor] = {SIDs[sid] : time.time()}
    # Update RXs and SIDs
    del RXs[SIDs[sid]]
    del SIDs[sid]
    print('RXS: ', RXs, 'SIDs: ', SIDs)



@sio.on("reg_rx")
def reg_rx(sid, data):
    """ Once a RX unit is connected to the server, it sends a list of its current registered sensor nodes to the server.
        This helps to handle temporary disconnection between Rx units and server.
    """
    print('reg_rx ', sid, data)
    rx_id = data['id']
    data = {sensor: all_sensors[sensor] for sensor in reg_sensors if (reg_sensors[sensor] == rx_id)}
    # update the RX unit with the list of available sensors on the sensor nodes
    if (len(data) > 0):
        sio.emit('sensors_reg', data, room= sid)
    # Update RXs and SIDs
    RXs[rx_id] = sid
    SIDs[sid] = rx_id
    print('RXS: ', RXs, 'SIDs: ', SIDs)



@sio.on("search_res")
def reg_tags(sid, data):
    """ This function processes the result of search routines received from RX units.
    """

    print('search_res ', sid, data)
    detected_sensors = []
    for tag in data:
        # remove sensor node from pending_sensor list,
        if (int(tag) in pending_sensor):
            pending_sensor.remove(int(tag))
        for TX in data[tag]:
            if (data[tag][TX] >= 1):
                detected_sensors.append(int(tag))
    # add all detected sensors to the reg_sensors, and remove them from missing sensors
    for tag in detected_sensors:
        reg_sensors[tag] = SIDs[sid]
        del miss_sensors[tag]
    # send a response with the details of available sensors on the detected sensor nodes back to the RX unit.
    resp = {sensor: all_sensors[sensor] for sensor in detected_sensors}
    sio.emit('sensors_reg', resp, room= sid)
    print ('Regs: ', reg_sensors, 'Miss: ', miss_sensors)



@sio.on("miss_tags")
def miss_tags(sid, data):
    """handles the missing sensor nodes notices from the RX units"""
    print('miss_tags ', sid, data)
    # remove sensor node from reg_sensors and add it to the miss_sensors
    for tag in data:
        del reg_sensors[tag]
        miss_sensors[tag] = {SIDs[sid] : time.time()}
    print ('Regs: ', reg_sensors, 'Miss: ', miss_sensors)




@sio.on("new_data")
def new_data(sid, data):
    """handles the reception of new data from RX units"""
    # save the data on disk
    global fname
    print('new_data ', sid, data)
    f = open(fname,"a")
    print(datetime.datetime.now().strftime("%H:%M:%S.%f"),',', file= f, end = '', sep='')
    print(SIDs[sid],',', file= f, end = '', sep='')
    for item in data:
        print(item,',', file= f, end = '', sep='')
    print('', file= f)
    f.close()



def init():
    global fname
    # Auto create logs if not already exist
    if not os.path.exists('logs'):
        os.makedirs('logs')
        if not os.path.exists('logs/server'):
            os.makedirs('logs/server')
    # Unique auto-increment log 
    prev_log = glob('logs/*.csv')
    if len(prev_log) == 0:
        test_index = 1 
    else:   
        test_index = max([int(os.path.basename(i).split('.')[0][8:]) for i in prev_log])+1
    fname = 'logs/server/log'+str(test_index)+'.txt'
    f = open(fname,"w+")
    print(print('time, RX, tag, temp, humid, illum', file = f))
    f.close()

    # add all the active sensors to the missing sensors
    for sensor in active_sensors:
        miss_sensors[sensor] = {}
        


def application():
    """ The server application.
        searches for missing sensor nodes in all connected RX units and updates assignements once a sensor node is found.
    """

    while (True):
        if (len(miss_sensors) > 0 and len(RXs) > 0):
            for tag in miss_sensors:
                next_rx = None
                # wait for the previous search result
                if (tag in pending_sensor):
                    continue
                # pick an RX unit randomly
                RXs_list = list(RXs)
                random.shuffle(RXs_list)
                for rx in RXs_list:
                    # if the RX unit is recently used to search for this sensor node, select next one.
                    if (rx not in miss_sensors[tag]) or (miss_sensors[tag][rx] == None):
                        next_rx = rx
                        break
                # ask the RX unit to search for the missinf sensor
                if (next_rx != None):
                    print('Searching for tag %d at Rx %d!'%(tag, next_rx))
                    sio.emit('sensors_missed', [tag], room = RXs[next_rx])
                    # add a timetag to keep track of last time the search has happened using this RX unit
                    miss_sensors[tag][next_rx] = time.time()
                    pending_sensor.append(tag)
                    # print('pending_sensor', pending_sensor)

                # update the miss_sensor. Make the RX units available for search again if the timeout has passed.  
                for rx in list(RXs):
                    if (rx in miss_sensors[tag]) and (miss_sensors[tag][rx] != None):
                        if ((datetime.datetime.fromtimestamp(time.time()) - datetime.datetime.fromtimestamp(miss_sensors[tag][rx])).total_seconds() > 10):
                            miss_sensors[tag][rx] = None
                
        #     sio.emit('sensors_missed', list(miss_sensors.keys()))
        sio.sleep(0.1)
        # print(miss_sensors, pending_sensor)

if __name__ == '__main__':
    print('server initiated!')
    init()
    sio.start_background_task(application)
    eventlet.wsgi.server(eventlet.listen(('', 5000)), app)
    
    
