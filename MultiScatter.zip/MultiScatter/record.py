from PIL import Image, ImageTk, ImageEnhance, ImageFilter
import numpy as np
import os
from datetime import datetime


cam_DIR = "recorded_images"

class record:
    """This class stores the recorded images on disk. (When no GUI is needed.)
    """
    def __init__(self, sensors, save):
        self.sensors = sensors
        self.save = save

    def submit_to_tkinter(self, callable, *args, **kwargs):
        return callable(*args, **kwargs)

    def update(self, data, data_ptrs, index, timeout):
        if (not timeout):
            # for i in range(self.cols):
            i = index
            tag = self.sensors.get_tags()[i]

            if (self.sensors.get_sensors()[tag]['cam']):
                array = data[i]['camera']
                im = Image.fromarray(array)
                #save image
                try:
                    os.mkdir(cam_DIR+str(tag))
                except:
                    pass
                if (self.save):
                    im.save(cam_DIR+str(tag) + '/'+ datetime.utcnow().strftime('%H.%M.%S.%f')[:-3]+".bmp")
            