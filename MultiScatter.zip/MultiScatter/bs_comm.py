import numpy as np
import random 
from rxInterface import rxInterface
from policy import *
from selector import selector_history
from collections import  deque


class bs_comm():
    """This class manages the backscatter links with the sensor nodes.

    Attributes
    ----------
    dev : rxInterface object to communicate with the RX board
    sensors : sensor_node object to manage the sensor nodes
    ant_div : if True, the TRXs with more than antenna use antenna diversity. Otherwise, they just use a default antenna.
    explore : if False, always the smart policy is selected.
    options : a dictionary with the parameters that must be selected as keys and their range as values.
    used_freq : a circular array of most recent used frequency channels.
    tag_policy : A list of list of policy_cross_entropy_rssi objects. each object represent the policy for a specific sensor_node and TX unit.
    tag_selector : A list of selector_history objects.
    rnd : random policy
    terminal : if True, the execution stops.
    """

    def __init__(self):
        self.dev = None    
        self.used_freq = None
        self.tag_policy = None
        self.tag_selector = None
        self.tag_power = None
        self.rnd = None
        self.terminal = None

    def init(self, port, sensors, filename = 'log.txt', ant_div = True, term_count = None, debug = True, explore = True):
        self.debug = debug
        self.dev = rxInterface(port=port, filename= filename, log= False, debug= self.debug, terminal_count= term_count)
        self.sensors = sensors
        self.ant_div = ant_div
        self.explore = explore
        # We have 65 frequency channels in 902-928 MHz IsM band. Channel spacing is 400KHz.
        self.options = {'freq': 65, 'tx_ant': 1, 'rx_ant': 1, 'wake':1, 'power':8}
        # The circular buffer size determines the minimum frequency re-use interval. 
        self.used_freq = deque(maxlen=5)
        self.tag_policy = []
        self.tag_selector = []
        self.rnd = policy_random(options = self.options)
        self.terminal = False


    def add_tag(self, tag_id):
        """ creates the policy and selector objects for a new sensor node."""
        self.tag_policy.append([])
        for j in range(len(self.sensors.get_TXs(tag_id))):
            self.tag_policy[-1].append(policy_cross_entropy_rssi(options = self.options))

        self.tag_selector.append(selector_history(hist_len = 100, explore=self.explore))

    def del_tag(self, index):
        """removes the policy and selector objects for a sensor node"""
        del self.tag_policy[index]
        del self.tag_selector[index]

    def cmd(self, cmd):
        """execute a command by selecting a configuration, sending data to the RX board, collecting the results, and updating the policy and selector objects."""
        #decode the command
        index = cmd[0]
        tag_cmd = cmd[1]
        dur = cmd[2]
        expected_pkts = cmd[3]

        # select a TX unit
        rates = []
        best_TX = -1
        for tx in range(len(self.sensors.get_TXs(self.sensors.get_tags()[index]))):
            rates.append(self.tag_policy[index][tx].get_rate())
        if (sum(rates) == 0):
            #all TX unit rates are equal to 0, select one randomly
            best_TX = random.randint(0, len(self.sensors.get_TXs(self.sensors.get_tags()[index]))-1)
        else:
            # TX units with rate higher than 0.8 are the elite ones. 
            elites = []
            elite_rates = []
            for i in range(len(rates)):
                if (rates[i] > 0.8):
                    elites.append(i)
                    elite_rates.append(rates[i])
            if (len(elites) > 0):
                # if we have elite TXs, we select one with a weighted random selection. The weights are proportional to the TX rates.
                s = sum(elite_rates)
                for i in range(len(elites)):
                    elite_rates[i] /= s
                    best_TX = elites[int(np.random.choice(len(elite_rates), 1, p=elite_rates)[0])]
            else:
                # if one TX unit has a much higher rate than the rest, we select that TX unit.
                s = sum(rates)
                for i in range(len(rates)):
                    rates[i] /= s
                    if (rates[i] > 0.8):
                        best_TX = i
                        break
            if (best_TX == -1):
                #if we have not selected a TX unit yet, we use weighted random selection over all TX units
                best_TX = int(np.random.choice(len(rates), 1, p=rates)[0])
        # print(rates, best_TX)

        # select a configuration
        if(random.uniform(0,1) < self.tag_selector[index].select()):
            config = self.rnd.action(self.used_freq, ant_div = self.ant_div)
        else:
            config = self.tag_policy[index][best_TX].action(self.used_freq, ant_div = self.ant_div)

        # send the command to the RX board and store the received packets
        self.terminal, attempt, pkt_count_crcOk, pkt_count_crcNok, rssi, pkts = self.dev.cmd(self.sensors.get_TXs(self.sensors.get_tags()[index])[best_TX], self.sensors.get_tags()[index], config, dur, tag_cmd)
        
        #calculate score and update the policy and selector objects
        success = 0
        if (attempt):
            success = min((pkt_count_crcOk + pkt_count_crcNok*0.0) / expected_pkts,1)
            if (rssi > -110):
                score = rssi - (-110)
            else:
                score = 0
            self.tag_policy[index][best_TX].update(config, success, score)
            self.tag_selector[index].update(config, success)
        
        #update the used_freq list
        self.used_freq.append(config[0])

        if (self.debug):
            print(',{:>5}, {:>8}'.format(np.round(success,3), np.round(self.tag_selector[index].get_success_rate(),3)))        

        return self.terminal, pkts

    def direct_cmd(self, tx_id, tag_id, tag_cmd, dur, expected_pkts, config):
        """sends a direct command to a sensor node, bypassing the configuration selection and policy updates. Mainly used in search routines."""
        self.terminal, attempt, pkt_count_crcOk, pkt_count_crcNok, rssi, pkts = self.dev.cmd(tx_id, tag_id, config, dur, tag_cmd)
        success = min((pkt_count_crcOk + pkt_count_crcNok*0.0) / expected_pkts,1)
        if (self.debug):
            print(', success = {:>5}'.format(np.round(success,3)))        
        return self.terminal, pkt_count_crcOk / expected_pkts

    def get_hist_rate(self, index, n, start):
        return self.tag_selector[index].get_hist(n, start)