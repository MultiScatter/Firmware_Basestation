import random
import numpy as np
import os
from PIL import Image 
import pandas as pd
from selector import selector_history
from cmds import commands

class sim_comm:
    def __init__(self, pktLen, pkt_prob):
        self.header = 1
        self.seqNumber = 0
        self.pktLen = pktLen
        self.pkt_crc = pkt_prob
        self.cam_row = 0
        self.cam_col = 0
        self.mic_idx = 0
        self.data = []
        self.tag_selector = []
    
    def add_tag(self, tag_id): # some tag_id doesn't exist in sim data pool
        self.data.append({
            # 'image_path' : "data/images"+str(tag_id)+'/', # some tag_id doesn't exist in sim data pool
            'image_path' : "data/images1/",
            'image_num' : 1,
            'image_total' : 18,
            'image' : np.zeros((120,120), dtype=np.uint8),
            # 'env_df' : pd.read_csv("./data/env"+str(tag_id)+".csv"), # some tag_id doesn't exist in sim data pool
            'env_df' : pd.read_csv("./data/env0.csv"),
            'env_index' : 0,
            'env_inc' : 1,
            'env_total' : 84000,
            })
        self.tag_selector.append(selector_history(hist_len = 100, explore=False))



    def cmd(self, cmd):
        """execute a command by selecting a configuration, sending data to the RX board, collecting the results, and updating the policy and selector objects."""
        index = cmd[0]
        tag_cmd = cmd[1]
        # dur = cmd[2]
        expected_pkts = cmd[3]

        pkts = []
        # READ_ENV
        if (tag_cmd == commands().READ_ENV):
            temp = self.data[index]['env_df']['temp'][self.data[index]['env_index']]
            humid = self.data[index]['env_df']['humid'][self.data[index]['env_index']]
            illum = self.data[index]['env_df']['illum'][self.data[index]['env_index']]
            # print(temp, humid, illum)
            arr = np.zeros(20, dtype = np.uint8)
            temp_16bit = ((temp + 40) * 65536) // 165
            arr[0] = np.uint8(temp_16bit % 256)
            arr[1] = np.uint8(temp_16bit // 256)
            humid_16bit = (humid * 65536) // 100
            arr[2] = np.uint8(humid_16bit % 256)
            arr[3] = np.uint8(humid_16bit // 256)
            illum_16bit = (illum * 146.21) // 1.2
            illum_exponent = 0
            while (illum_16bit >= 4096):
                illum_16bit /= 2
                illum_exponent += 1
            arr[4] = np.uint8(illum_16bit % 256)
            arr[5] = np.uint8(illum_16bit // 256 + illum_exponent * 16)
            # print(arr)

            for i in range(expected_pkts):
                pkt = self.gen_pkt()
                pkt['tag_str'][0] = tag_cmd
                pkt['tag_seqNumber'] =  0
                pkt['tag_str'][1:21] = bytearray(arr)
                pkts.append(pkt)
            # sleep(0.02)

            self.data[index]['env_index'] += 1

        # TAKE_PIC
        if (tag_cmd == commands().TAKE_PIC):
            for i in range(expected_pkts):
                pkt = self.gen_random_pkt()
                pkt['tag_str'][0] = tag_cmd
                pkts.append(pkt)

            im = Image.open(self.data[index]['image_path'] + str(self.data[index]['image_num']) + '.png')
            self.data[index]['image'] = np.asarray(im)
            self.data[index]['image'] = self.data[index]['image'][1:121, 21:141]

            im.close()
            self.data[index]['image_num'] += 1
            if (self.data[index]['image_num'] == self.data[index]['image_total']):
                self.data[index]['image_num'] = 1 
            # sleep(1)
        
        #READ_PIC_POR
        if (tag_cmd & 0xF0 == commands().READ_PIC_POR or tag_cmd & 0x80 == commands().READ_PIC_ROW):
            if (tag_cmd & 0xF0 == commands().READ_PIC_POR):
                row = (tag_cmd - 0x10) * 10
                col = 0
            else:
                row = tag_cmd - 0x80
                col = 0
            for i in range(expected_pkts):
                pkt = self.gen_pkt()
                pkt['tag_str'][0] = tag_cmd
                pkt['tag_seqNumber'] =  row + col * 256
                pkt['tag_str'][1:21] = bytearray(self.data[index]['image'][row, col:col+20])
                col += 20
                if (col == 120):
                    col = 0
                    row += 1
                    if(row == 120):
                        row = 0
                pkts.append(pkt)
            # sleep(0.1)
        
        # print(pkts)
        return False, pkts

    def gen_random_pkt(self):
        pkt = self.gen_pkt()
        pkt['tag_str'] = bytearray(os.urandom(self.pktLen))
        pkt['tag_seqNumber'] =  self.seqNumber
        self.seqNumber += 1
        if(self.seqNumber == 65536):
            self.seqNumber = 0
        return pkt
        
    def gen_pkt(self):
        pkt = {}
        pkt['tag_header'] = self.header
        pkt['tag_str'] = np.zeros(self.pktLen)
        if(random.uniform(0,1) < self.pkt_crc):
            pkt['tag_crc'] = 1
        else:
            pkt['tag_crc'] = 0
        
        if(pkt['tag_crc'] == 0):
            pkt['tag_rssi'] = -256
        else:
            pkt['tag_rssi'] = np.random.normal(-80, 5, 1)

        return pkt

    def direct_cmd(self, tx_id, tag_id, tag_cmd, dur, expected_pkts, config):    
        return False, random.uniform(0,1)

    def get_hist_rate(self, index, n, start):
        return self.tag_selector[index].get_hist(n, start)