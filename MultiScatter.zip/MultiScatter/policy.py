import numpy as np
import random 


def_tx_ant = 0
def_rx_ant = 1

class policy:
    """This class implements a policy for backscatter configuration selection.
    A configuration is a set of parameters (such as CW excitation freq and power) that must be fixed before the communication happens.
    A good policy selects the configurations that maximize the backscatter communication success rate.

    Attributes
    ----------
    options: a dictionary with the parameters that must be selected as keys and their range as values.
    total_options: the total number of possible configurations
    rate: exponential moving average of the success rate
    rate_eps: update coefficient
    """

    def __init__(self, options):
        self.options = options
        self.total_options = self.options['freq'] * self.options['tx_ant'] * self.options['rx_ant'] * self.options['wake']
        self.rate = 0.5
        self.rate_eps = 0.9

    def get_rate(self):
        return self.rate

    def update_rate(self, res):
        self.rate = self.rate_eps * self.rate + (1-self.rate_eps) * res

class policy_random (policy):
    """This class implements a random configuration selection policy.
    """

    def __init__(self, options):
        super().__init__(options)
        pass

    def action(self, freq_black_list, ant_div):
        """This functioins returns a configuration.
        In policy_random all parameters are selected randomly.

        Args:
            freq_black_list: Frequency hopping systems have some limits on using frequency channels.
            This list specifies the frequency channels that cannot be used in the frequency selection process.
            ant_div: if True, the TRXs with more than antenna use antenna diversity. Otherwise, they just use a default antenna.

            
        Returns:
            a configuration (A list of parameters)
        """
        count  = 1
        while (count <= len(freq_black_list)+1):
            freq_index = random.randint(0, self.options['freq']-1)
            if (freq_index not in freq_black_list):
                break
            count += 1
        if (ant_div):
            tx_ant = random.randint(0, self.options['tx_ant']-1)
            rx_ant = random.randint(0, self.options['rx_ant']-1)
        else:
            tx_ant = def_tx_ant
            rx_ant = def_rx_ant
        wakeup = random.randint(0, self.options['wake']-1)
        power = random.randint(0, self.options['power']-1)
        
        self.config = [freq_index, tx_ant, rx_ant, wakeup, power]
        return self.config

    def update(self, config, res, score):
        self.update_rate(res)

class policy_cross_entropy_rssi (policy):  
    """This class implements a configuration selection policy based on a scoring system.
    We assign two score to each configuration and update both scores each time the configration is used.
    The two scores have different update rates.
    To select a configuration, we select the one with the highest score that satisfies the freq hopping requirement.
    We use a seperate score vector for power variable.

    Attributes
    ----------
    ma_fast: score vector with fast update rate
    ma_slow: score vector with slow update rate
    update_rate_fast: ma_fast update coefficient
    update_rate_slow: ma_slow update coefficient
    power_list: list of possible values for the power variable
    power_suc: score vector for the power variable
    power_update_rate: power score vector update coefficient
    """

    def __init__(self, options, update_rate_fast = 0.98, update_rate_slow = 0.8):
        super().__init__(options)
        self.ma_fast = np.full((self.options['freq'], self.options['tx_ant'], self.options['rx_ant'], self.options['wake']), 0.0)  #moving averages matrix
        self.ma_slow = np.full((self.options['freq'], self.options['tx_ant'], self.options['rx_ant'], self.options['wake']), 0.0)  #moving averages matrix
        self.update_rate_fast = update_rate_fast
        self.update_rate_slow = update_rate_slow
        self.config = []
        self.power_list = [i for i in range(self.options['power'])]
        self.power_suc = np.zeros(self.options['power'])
        self.power_update_rate = 0.9


    def reset_scores(self):
        # clears the scores for all the configurations
        self.ma_fast = np.full((self.options['freq'], self.options['tx_ant'], self.options['rx_ant'], self.options['wake']), 0.0)  #moving averages matrix
        self.ma_slow = np.full((self.options['freq'], self.options['tx_ant'], self.options['rx_ant'], self.options['wake']), 0.0)  #moving averages matrix
        self.power_suc = np.zeros(self.options['power'])



    def action(self, freq_black_list, ant_div):
        """This functioins returns a configuration.
        the power with highest score is selected. with a small chance, we use a power slightly higher or lower to explore.
        We select one of the slow or fast score vectors randomly. Then select the configuration with the highest score in that vector given the freq hopping requirements.

        Args:
            freq_black_list: Frequency hopping systems have some limits on using frequency channels.
            This list specifies the frequency channels that cannot be used in the frequency selection process.
            ant_div: if True, the TRXs with more than antenna use antenna diversity. Otherwise, they just use a default antenna.

            
        Returns:
            a configuration (A list of parameters)
        """

        #power selection
        power_id = np.argmax(self.power_suc)
        if(random.uniform(0,1) < 0.3 and power_id > 0):
            power_id -= 1
        if(random.uniform(0,1) < 0.3 and power_id < self.options['power']-1):
            power_id += 1
        power = self.power_list[power_id]

        #select one of the slow or fast vectors randomly
        if(random.uniform(0,1) < 0.5):
            ma = self.ma_fast
        else:
            ma = self.ma_slow
        count  = 1
        tried_freq = []
        best_config = None
        while (True):
            #select the threshold (initially is set to select one score)
            th_score = np.partition(ma.flatten(), -count)[-count]
            #find all the configs above the threshold
            max_config = np.where(ma >= th_score)
            listOfConfigs = list(zip(max_config[0], max_config[1], max_config[2], max_config[3]))
            if(len(listOfConfigs) == self.total_options):
                # all configs have the same score (most probably on the cold start). select one randomly
                count  = 1
                while (count <= (len(freq_black_list)+1)):
                    freq_index = random.randint(0, self.options['freq']-1)
                    if (freq_index not in freq_black_list):
                        break
                    count += 1
                if (ant_div):
                    tx_ant = random.randint(0, self.options['tx_ant']-1)
                    rx_ant = random.randint(0, self.options['rx_ant']-1)
                else:
                    tx_ant = def_tx_ant
                    rx_ant = def_rx_ant
                wakeup = random.randint(0, self.options['wake']-1)
                self.config = [freq_index, tx_ant, rx_ant, wakeup, power]
                return self.config
            
            else:

                for index in range(len(listOfConfigs)):
                    # check if any of the configs pass the frequecy hopping and antenna requirements
                    config = listOfConfigs[index]
                    if(not ant_div):
                        if(config[1] != def_tx_ant | config[2] != def_rx_ant):
                            continue
                    if (config[0] not in freq_black_list):
                        best_config = config
                        break
                    else:
                        if (config[0] not in tried_freq):
                            tried_freq.append(config[0])
                    if (config[0] == freq_black_list[0]):
                        def_config = config
                    if(len(tried_freq) == len(freq_black_list)):
                        best_config == def_config
                        break
                # if no configuration is selected, lower the threshold
                if(best_config != None):
                    break
                count += 1
   
        freq_index = best_config[0]
        tx_ant = best_config[1]
        rx_ant = best_config[2]
        wakeup = best_config[3]
        self.config = [freq_index, tx_ant, rx_ant, wakeup, power]
        return self.config

    def update(self, config, res, score):
        """ update all score vectors with the backscatter communication results
        """
        self.update_rate(res)
        freq_index = config[0]
        tx_ant = config[1]
        rx_ant = config[2]
        wakeup = config[3]
        power = config[4]
        self.ma_fast[freq_index, tx_ant, rx_ant, wakeup] = self.update_rate_fast * self.ma_fast[freq_index, tx_ant, rx_ant, wakeup] + (1-self.update_rate_fast) * res * score
        self.ma_slow[freq_index, tx_ant, rx_ant, wakeup] = self.update_rate_slow * self.ma_slow[freq_index, tx_ant, rx_ant, wakeup] + (1-self.update_rate_slow) * res * score

        self.power_suc[power] = self.power_update_rate * self.power_suc[power] + (1 - self.power_update_rate) * res
